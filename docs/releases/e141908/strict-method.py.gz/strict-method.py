"""72ca500 실제 exe 결과와 승인된 연결 원자료를 거쳐 새 소스 전행을 대조한다."""
import collections,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
P=Path('F:/sheet-music-helper-codex-night-20261004')
C=Path('C:/Users/정혁/Desktop/akbo_kca/debug/sim_lp/dblconn')
W=R/'output/strict-double-connection'; W.mkdir(exist_ok=False)
from tools.compare_beta_labels import count_changes
from modules.label_audio import pitch_to_midi
oldverify=json.loads((R/'docs/releases/72ca500/verification.json').read_bytes())
known={r['case']:r for r in oldverify['cases']}
oldstrict={r['case']:r for r in json.loads(gzip.decompress((R/'docs/releases/72ca500/strict-result.json.gz').read_bytes()))}
oldmeta=json.loads((R/'docs/releases/72ca500/artifacts.json').read_bytes())
with Path(oldmeta['exe']['path']).open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest().upper()==oldmeta['exe']['sha256']
cases=[('aoharu_p1',R/'sample_images/KakaoTalk_20260731_162400402.png','aoharu1'),('aoharu_p2',R/'sample_images/KakaoTalk_20260731_162400402_01.png','aoharu2'),('aoharu_p3',R/'sample_images/KakaoTalk_20260731_162400402_02.png','aoharu3'),('chopin_Db_p1',R/'tests/fixtures/selftest/chopin_Db_p1.png','db1'),('bach_p1',P/'output/night-inputs/bach_p1.png','bach'),('clef_change_clara1',R/'test_scores/verovio/clara_polonaise_1_bravura_p1.png','clara_polonaise_1_bravura_p1'),('alto_beethoven1',R/'test_scores/verovio/beethoven_op18no1_bravura_p1.png','beethoven_op18no1_bravura_p1'),('schubert_restored',R/'test_scores/verovio/schubert_lindenbaum_piano_leipzig_p1.png','schubert_lindenbaum_piano_leipzig_p1')]
for alias,stem in [('clara1_leipzig','clara_polonaise_1_leipzig_p1'),('clara2_bravura','clara_polonaise_2_bravura_p1'),('clara2_leipzig','clara_polonaise_2_leipzig_p1'),('schubert_bravura','schubert_lindenbaum_piano_bravura_p1')]:cases.append((alias,R/'test_scores/verovio'/(stem+'.png'),stem))
enc=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
count=lambda labels:collections.Counter(map(enc,labels))
env=dict(os.environ,PYTHONIOENCODING='utf-8'); results=[]; refs=[]
for case,path,stem in cases:
    assert path.is_file(),path
    before=json.loads((P/known[case]['exe_json']).read_bytes())
    assert before==oldstrict[case]['after'],(case,'이전 exe 출력의 보존 원문 불일치')
    assert hashlib.sha256(path.read_bytes()).hexdigest()==before['source']['sha256']==known[case]['input_sha256']
    raw=(C/(stem+'.json')).read_bytes(); ref=json.loads(raw)
    target=W/case
    run=subprocess.run([sys.executable,'gui.py','--selftest',str(path),str(target)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (W/(case+'.log')).write_bytes(run.stdout);assert run.returncode==0,(case,run.returncode,run.stdout[-900:])
    actual,=target.glob('*_라벨.json');after=json.loads(actual.read_bytes())
    assert {k:v for k,v in before.items() if k not in ('schema','labels')}=={k:v for k,v in after.items() if k not in ('schema','labels')},(case,'문맥/입력 변화')
    assert after['schema']==(2 if any(l['accidental'] in ('bb','##') for l in after['labels']) else 1)
    assert len(before['labels'])==len(after['labels'])==len(ref['labels']),(case,'추가/삭제')
    assert count(after['labels'])==count(ref['labels']),(case,'CLI 승인 원자료와 새 labels 전체행 불일치')
    for old,new in zip(before['labels'],after['labels']):
        assert {k:v for k,v in old.items() if k not in ('accidental','text','confidence','flags','key')}=={k:v for k,v in new.items() if k not in ('accidental','text','confidence','flags','key')},(case,old['x'],old['y'],'허용 밖 변화')
        if old['text']!=new['text'] or old['accidental']!=new['accidental']:
            assert new['accidental'] in ('bb','##') and new['text'].endswith(new['accidental']) and new['confidence']=='check' and 'double_acc' in new['flags']
        if old['confidence']!=new['confidence']:assert (old['confidence'],new['confidence'])==('certain','check') and 'side_pair' in new['flags']
        assert [f for f in new['flags'] if f!='side_pair' or f in old['flags']]==old['flags'],(case,'승인 밖 신호 변화')
        if 'key' in old:assert new.get('key')==old['key']
        if 'key' in new:assert isinstance(new['key'],dict) and new['key'].get('notation',after['music']['notation'])==after['music']['notation']
        assert pitch_to_midi(new,after['music'])==pitch_to_midi(dict(new,edited=True),dict(after['music'],notation='solfege')),(case,new['x'],new['y'],'표기/재생 불일치')
    if case.startswith('aoharu'):assert before==after,(case,'골든 기본 JSON 변화')
    if case in ('aoharu_p1','chopin_Db_p1'):assert actual.read_text(encoding='utf-8')==(R/'tests/fixtures/selftest'/(case+'.json')).read_text(encoding='utf-8')
    changes,diff=count_changes(before,after)
    row=dict(case=case,input=str(path),reference_stem=stem,before=before,after=after,counts=changes,differences=diff)
    results.append(row);refs.append(dict(case=case,sha256=hashlib.sha256(raw).hexdigest(),document=ref))
    (W/'result.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(case,len(after['labels']),changes,'승인 원자료 전행·표기/재생 일치',flush=True)
with gzip.open(W/'cli-accepted-references.json.gz','wb') as stream:stream.write(json.dumps(refs,ensure_ascii=False).encode())
identity={str(p.relative_to(R)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*R.glob('modules/*.py'),R/'main.py',R/'gui.py',R/'user_messages.py',*R.glob('assets/*')] if p.is_file()}
(W/'source-identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('STRICT_COMPLETE: 추가·삭제·좌표·음고·문맥 변화0 / 승인 #387·#390·#388/391 외 변화0',flush=True)
