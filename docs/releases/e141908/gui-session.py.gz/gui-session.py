"""기존 SendInput 도구를 재사용하고 입력 상태 복원·검사 사본 종료를 finally로 묶는다."""
import ctypes as c,ctypes.wintypes as w,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'output/human-beta-e141908';OUT.mkdir(exist_ok=True)
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'output/tmp');os.environ['PYTHONIOENCODING']='utf-8'
source=(ROOT/'output/native-linked-beta.py').read_text(encoding='utf-8')
header,body=source.split('cmd=sys.argv[1]',1);ns={'__name__':'native_check'};exec(header,ns)
u=ns['u'];u.GetForegroundWindow.restype=w.HWND
class GT(c.Structure):_fields_=[('cbSize',w.DWORD),('flags',w.DWORD),('active',w.HWND),('focus',w.HWND),('capture',w.HWND),('menu',w.HWND),('move',w.HWND),('caret',w.HWND),('rect',w.RECT)]
g=GT();g.cbSize=c.sizeof(g);assert u.GetGUIThreadInfo(0,c.byref(g))
original_foreground=u.GetForegroundWindow();original_num=bool(u.GetKeyState(144)&1)
im=c.WinDLL('imm32');im.ImmGetDefaultIMEWnd.argtypes=[w.HWND];im.ImmGetDefaultIMEWnd.restype=w.HWND
original_ime=im.ImmGetDefaultIMEWnd(g.focus)
u.SendMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];u.SendMessageW.restype=w.LPARAM
original_mode=int(u.SendMessageW(original_ime,0x283,1,0)) if original_ime else None
baseline=dict(original_foreground=int(original_foreground or 0),original_focus=int(g.focus or 0),original_numlock=original_num,original_ime_hwnd=int(original_ime or 0),original_ime_conversion=original_mode)
(OUT/'baseline.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
start=time.monotonic();cleanup=dict(baseline=baseline)
try:
    print('READY '+json.dumps(baseline),flush=True)
    for line in sys.stdin:
        args=json.loads(line)
        if args==['finish']:break
        assert time.monotonic()-start<900,'실제 입력 검사 15분 제한'
        assert isinstance(args,list) and all(isinstance(v,str) for v in args)
        sys.argv=[str(ROOT/'output/native-linked-beta.py')]+args
        try:exec('cmd=sys.argv[1]'+body,ns)
        except SystemExit as error:
            if error.code not in (None,0):raise
        print('DONE '+json.dumps(args,ensure_ascii=False),flush=True)
finally:
    try:
        own=[]
        for window in ns['windows']():
            try:ns['guard_own_window'](window['hwnd']);own.append(window)
            except Exception:pass
        roots=[r for r in own if r['title']=='악보헬퍼 - 계이름 자동 표기']
        if bool(u.GetKeyState(144)&1)!=original_num:
            assert roots,'NumLock 복원할 검사 앱이 없음'
            u.SetForegroundWindow(roots[0]['hwnd']);ns['key'](144);ns['key'](144,True);time.sleep(.2)
        cleanup['numlock_restored']=bool(u.GetKeyState(144)&1)==original_num
        if original_ime and u.IsWindow(original_ime):
            u.SendMessageW(original_ime,0x283,2,original_mode)
            cleanup['ime_restored']=int(u.SendMessageW(original_ime,0x283,1,0))==original_mode
        else:cleanup['ime_restored']='원래 IME 컨텍스트 없음/사라짐 — 직접 비교 불가'
        for window in own:u.PostMessageW(window['hwnd'],16,0,0)
        time.sleep(1)
    except Exception as error:cleanup['restore_error']=repr(error)
    finally:
        exe=str((OUT/'app/악보헬퍼.exe').resolve()).replace("'","''")
        script="$items=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -eq '"+exe+"'});foreach($item in $items){Stop-Process -Id $item.ProcessId -Force -ErrorAction SilentlyContinue};@((Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -eq '"+exe+"'})|Select-Object ProcessId,ExecutablePath)|ConvertTo-Json -Compress"
        result=subprocess.run(['powershell','-NoProfile','-Command',script],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        cleanup['remaining_process_query']=result.stdout.decode('utf-8',errors='replace').strip();cleanup['closed_own_copies']=result.returncode==0 and cleanup['remaining_process_query'] in ('','[]')
        if original_foreground and u.IsWindow(original_foreground):u.SetForegroundWindow(original_foreground)
        cleanup['finished_at']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
        (OUT/'cleanup.json').write_text(json.dumps(cleanup,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('CLEANUP '+json.dumps(cleanup,ensure_ascii=False),flush=True)
