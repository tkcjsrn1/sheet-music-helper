import ctypes as c, ctypes.wintypes as w, json,sys,time,os,subprocess,zipfile,hashlib
from pathlib import Path
from PIL import ImageGrab
ROOT=Path('F:/sheet-music-helper-beta-13d73f6-record-20261018'); OUT=ROOT/'output/human-beta-e141908'; OUT.mkdir(exist_ok=True)
u=c.windll.user32
try:u.SetProcessDPIAware()
except:pass
u.GetAncestor.argtypes=[w.HWND,w.UINT];u.GetAncestor.restype=w.HWND
u.WindowFromPoint.argtypes=[w.POINT];u.WindowFromPoint.restype=w.HWND
u.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,c.c_int]
u.GetWindowRect.argtypes=[w.HWND,c.POINTER(w.RECT)]
CALLBACK=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
def info(h):
 s=c.create_unicode_buffer(1024); u.GetWindowTextW(h,s,1024); r=w.RECT();u.GetWindowRect(h,c.byref(r));pid=w.DWORD();u.GetWindowThreadProcessId(h,c.byref(pid));cls=c.create_unicode_buffer(256);u.GetClassNameW(h,cls,256)
 return dict(hwnd=int(h or 0),title=s.value,pid=pid.value,rect=[r.left,r.top,r.right,r.bottom],cls=cls.value,visible=bool(u.IsWindowVisible(h)))
def windows():
 a=[]
 @CALLBACK
 def cb(h,l):
  if u.IsWindowVisible(h):a.append(info(h))
  return True
 u.EnumWindows(cb,0);return a
class MI(c.Structure):_fields_=[('dx',w.LONG),('dy',w.LONG),('mouseData',w.DWORD),('dwFlags',w.DWORD),('time',w.DWORD),('dwExtraInfo',c.c_size_t)]
class KI(c.Structure):_fields_=[('wVk',w.WORD),('wScan',w.WORD),('dwFlags',w.DWORD),('time',w.DWORD),('dwExtraInfo',c.c_size_t)]
class HI(c.Structure):_fields_=[('uMsg',w.DWORD),('wParamL',w.WORD),('wParamH',w.WORD)]
class IU(c.Union):_fields_=[('mi',MI),('ki',KI),('hi',HI)]
class INPUT(c.Structure):_anonymous_=('v',);_fields_=[('type',w.DWORD),('v',IU)]
u.SendInput.argtypes=[w.UINT,c.POINTER(INPUT),c.c_int]
def send(i):
 if u.SendInput(1,c.byref(i),c.sizeof(i))!=1:raise RuntimeError('SendInput failed')
def guard_own_window(h=None):
 # 검사 사본의 전면 창/대화상자에만 키 입력한다.
 u.GetForegroundWindow.restype=w.HWND
 h=u.GetForegroundWindow() if h is None else h;pid=w.DWORD();u.GetWindowThreadProcessId(h,c.byref(pid))
 k=c.windll.kernel32;k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
 k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,c.POINTER(w.DWORD)]
 k.CloseHandle.argtypes=[w.HANDLE]
 handle=k.OpenProcess(0x1000,False,pid.value)
 if not handle:raise RuntimeError('전면 창 실행 경로를 확인하지 못했습니다.')
 try:
  size=w.DWORD(32768);name=c.create_unicode_buffer(size.value)
  if not k.QueryFullProcessImageNameW(handle,0,name,c.byref(size)):raise RuntimeError('검사 앱 경로 확인 실패')
  if Path(name.value).resolve()!= (OUT/'app'/'악보헬퍼.exe').resolve():raise RuntimeError('검사 사본 이외의 창에는 입력하지 않습니다.')
 finally:k.CloseHandle(handle)
def key(v,up=False):
 guard_own_window()
 if not up:key_context(v)
 send(INPUT(type=1,ki=KI(v,0,2 if up else 0,0,0)))
def text(t):
 guard_own_window()
 for b in t.encode('utf-16-le')[::2]:pass
 raw=t.encode('utf-16-le')
 for k in range(0,len(raw),2):
  s=int.from_bytes(raw[k:k+2],'little');guard_own_window();send(INPUT(type=1,ki=KI(0,s,4,0,0)));send(INPUT(type=1,ki=KI(0,s,6,0,0)));time.sleep(.006)
def log(d):
 d['utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());print(json.dumps(d,ensure_ascii=False),flush=True)
 with (OUT/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(d,ensure_ascii=False)+'\n')
def key_context(vk):
 guard_own_window()
 class GT(c.Structure):_fields_=[('cbSize',w.DWORD),('flags',w.DWORD),('active',w.HWND),('focus',w.HWND),('capture',w.HWND),('menu',w.HWND),('move',w.HWND),('caret',w.HWND),('rect',w.RECT)]
 g=GT();g.cbSize=c.sizeof(g);assert u.GetGUIThreadInfo(0,c.byref(g))
 log(dict(action='before_key',vk=vk,foreground=info(u.GetForegroundWindow()),os_focus=info(g.focus),numlock=bool(u.GetKeyState(144)&1),tk_focus='외부 frozen exe 직접 조회 불가; 소스 실제 추적과 구분'))

cmd=sys.argv[1]
if cmd=='baseline':
 class GT(c.Structure):_fields_=[('cbSize',w.DWORD),('flags',w.DWORD),('active',w.HWND),('focus',w.HWND),('capture',w.HWND),('menu',w.HWND),('move',w.HWND),('caret',w.HWND),('rect',w.RECT)]
 g=GT();g.cbSize=c.sizeof(g);assert u.GetGUIThreadInfo(0,c.byref(g))
 im=c.WinDLL('imm32');im.ImmGetDefaultIMEWnd.argtypes=[w.HWND];im.ImmGetDefaultIMEWnd.restype=w.HWND
 ime=im.ImmGetDefaultIMEWnd(g.focus);u.SendMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];u.SendMessageW.restype=w.LPARAM
 mode=int(u.SendMessageW(ime,0x283,1,0)) if ime else None
 log(dict(action='baseline',numlock=bool(u.GetKeyState(144)&1),native=bool(mode&1) if mode is not None else None,ime_available=bool(ime)))
 sys.exit(0)
if cmd=='num_status':
 guard_own_window();log(dict(action='num_status',numlock=bool(u.GetKeyState(144)&1),foreground=info(u.GetForegroundWindow())));sys.exit(0)
if cmd in ('ime','ime_status'):
 guard_own_window()
 class GT(c.Structure):_fields_=[('cbSize',w.DWORD),('flags',w.DWORD),('active',w.HWND),('focus',w.HWND),('capture',w.HWND),('menu',w.HWND),('move',w.HWND),('caret',w.HWND),('rect',w.RECT)]
 g=GT();g.cbSize=c.sizeof(g);assert u.GetGUIThreadInfo(0,c.byref(g))
 im=c.WinDLL('imm32');im.ImmGetDefaultIMEWnd.argtypes=[w.HWND];im.ImmGetDefaultIMEWnd.restype=w.HWND;ime=im.ImmGetDefaultIMEWnd(g.focus)
 u.SendMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];u.SendMessageW.restype=w.LPARAM
 mode=int(u.SendMessageW(ime,0x283,1,0));want=int(sys.argv[2]) if cmd=='ime' else int(bool(mode&1))
 if bool(mode&1)!=bool(want):key(21);key(21,True);time.sleep(.2);mode=int(u.SendMessageW(ime,0x283,1,0))
 log(dict(action='ime',requested_native=bool(want),conversion=mode,native=bool(mode&1),foreground=info(u.GetForegroundWindow()),os_focus=info(g.focus),tk_focus='외부 frozen exe에서 Tcl send 없음: 직접 조회 불가; 같은소스 진단에서 별도 기록'))
 sys.exit(0)
if cmd=='release_control':
 key(17,True);log(dict(action='release_control'));sys.exit(0)
if cmd=='scan':
 guard_own_window();v=int(sys.argv[2]);key_context(v);sc=u.MapVirtualKeyW(v,0);send(INPUT(type=1,ki=KI(0,sc,8,0,0)));time.sleep(.09);send(INPUT(type=1,ki=KI(0,sc,10,0,0)));log(dict(action='scan',vk=v,scan=sc));sys.exit(0)
if cmd=='key':
 key(int(sys.argv[2]));key(int(sys.argv[2]),True);log(dict(action='key',vk=int(sys.argv[2]),window=info(u.GetForegroundWindow())));sys.exit(0)
if cmd=='launch':
 dest=OUT/'app';dest.mkdir(exist_ok=True)
 selection=json.loads((ROOT/'output/build-selection.json').read_text(encoding='utf-8')); z=ROOT/'dist'/('악보헬퍼-'+selection['tag']+'.zip')
 with zipfile.ZipFile(z) as f:
  if not (dest/'악보헬퍼.exe').exists():f.extractall(dest)
 meta=json.loads((dest/'build-info.json').read_text(encoding='utf-8'));assert meta['commit']==selection['commit'] and not meta['dirty'],'선택 빌드와 다른 검사 사본'
 exe=dest/'악보헬퍼.exe';sha=hashlib.sha256(exe.read_bytes()).hexdigest();assert sha.upper()==meta['exe']['sha256']
 p=subprocess.Popen([str(exe)],cwd=dest);(OUT/'pid.txt').write_text(str(p.pid));log(dict(action='launch',pid=p.pid,sha256=sha));time.sleep(3);print(json.dumps([q for q in windows() if q['title']=='악보헬퍼 - 계이름 자동 표기'],ensure_ascii=False))
elif cmd=='own_windows':print(json.dumps([q for q in windows() if q['pid']==int(sys.argv[2])],ensure_ascii=False))
elif cmd=='list':print(json.dumps([q for q in windows() if q['title']=='악보헬퍼 - 계이름 자동 표기'],ensure_ascii=False))
elif cmd=='top':
 h=int(sys.argv[2]);guard_own_window(h);u.ShowWindow(h,9);u.SetWindowPos.argtypes=[w.HWND,w.HWND,c.c_int,c.c_int,c.c_int,c.c_int,w.UINT]
 u.SetWindowPos(h,w.HWND(-1),0,0,0,0,0x43);u.SetForegroundWindow(h);log(dict(action='top',window=info(h)))
elif cmd=='focus':
 h=int(sys.argv[2]);guard_own_window(h);u.ShowWindow(h,9);ok=u.SetForegroundWindow(h)
 if not ok:
  fg=u.GetForegroundWindow();current=c.windll.kernel32.GetCurrentThreadId();other=u.GetWindowThreadProcessId(fg,None)
  attached=u.AttachThreadInput(current,other,True)
  try:ok=u.SetForegroundWindow(h)
  finally:
   if attached:u.AttachThreadInput(current,other,False)
 u.MoveWindow(h,20,20,1150,760,True);time.sleep(.5);log(dict(action='focus',ok=ok,window=info(h)))
elif cmd=='shot':
 h=int(sys.argv[2]);guard_own_window(h);r=info(h)['rect'];p=OUT/(sys.argv[3]+'.png');ImageGrab.grab(bbox=tuple(r)).save(p);print(p)
elif cmd=='click_relative':
 h=int(sys.argv[2]);guard_own_window(h);r=info(h)['rect'];x=r[2]-int(sys.argv[3]);y=r[1]+int(sys.argv[4]);sys.path.insert(0,str(ROOT/'tests'));from _native_click import click_at
 pid=w.DWORD();u.GetWindowThreadProcessId(h,c.byref(pid));d=click_at(h,pid.value,x,y);log(dict(action='click_relative',rect=r,**d))
elif cmd=='click':
 h=int(sys.argv[2]);guard_own_window(h);x=int(sys.argv[3]);y=int(sys.argv[4]);sys.path.insert(0,str(ROOT/'tests'));from _native_click import click_at
 pid=w.DWORD();u.GetWindowThreadProcessId(h,c.byref(pid));d=click_at(h,pid.value,x,y);log(dict(action='click',**d))
elif cmd=='type_file':text(Path(sys.argv[2]).read_text(encoding='utf-8'))
elif cmd=='type':text(sys.argv[2])
elif cmd=='enter':key(13);key(13,True)
elif cmd=='ctrl_a':key(17);key(65);key(65,True);key(17,True)
elif cmd=='children':
 a=[]
 @CALLBACK
 def cb(h,l):a.append(info(h));return True
 u.EnumChildWindows(int(sys.argv[2]),cb,0);print(json.dumps(a,ensure_ascii=False))
elif cmd=='scroll':
 h=int(sys.argv[2]);guard_own_window(h);x=int(sys.argv[3]);y=int(sys.argv[4]);u.SetCursorPos(x,y);actual=w.POINT();u.GetCursorPos(c.byref(actual));assert (actual.x,actual.y)==(x,y);owner=u.GetAncestor(u.WindowFromPoint(w.POINT(x,y)),2);log(dict(action='scroll',xy=[x,y],expected=info(h),hit_top=info(owner)))
 if int(owner)!=h:raise RuntimeError('scroll blocked: another window')
 send(INPUT(type=0,mi=MI(0,0,(-120*int(sys.argv[5]))&0xffffffff,0x800,0,0)))
elif cmd=='close':
 h=int(sys.argv[2]);guard_own_window(h);u.PostMessageW(h,16,0,0)
