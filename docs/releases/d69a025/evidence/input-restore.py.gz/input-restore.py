"""감시 Job 바깥에서 입력 상태를 보존한다. Job 강제 중단에도 복원한다."""
import ctypes as c,ctypes.wintypes as w,json,sys,time
from pathlib import Path
u=c.WinDLL('user32');im=c.WinDLL('imm32')
u.GetForegroundWindow.restype=w.HWND
class GT(c.Structure):_fields_=[('cbSize',w.DWORD),('flags',w.DWORD),('active',w.HWND),('focus',w.HWND),('capture',w.HWND),('menu',w.HWND),('move',w.HWND),('caret',w.HWND),('rect',w.RECT)]
im.ImmGetDefaultIMEWnd.argtypes=[w.HWND];im.ImmGetDefaultIMEWnd.restype=w.HWND
u.SendMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];u.SendMessageW.restype=w.LPARAM
u.IsWindow.argtypes=[w.HWND];u.SetForegroundWindow.argtypes=[w.HWND]
def snapshot():
 g=GT();g.cbSize=c.sizeof(g);assert u.GetGUIThreadInfo(0,c.byref(g));ime=im.ImmGetDefaultIMEWnd(g.focus)
 return dict(foreground=int(u.GetForegroundWindow() or 0),ime=int(ime or 0),conversion=int(u.SendMessageW(ime,0x283,1,0)) if ime else None,numlock=bool(u.GetKeyState(144)&1))
def restore(s):
 sys.path.insert(0,'F:/akbo-data/tmp/beta-features-20261023/tests')
 from _native_click import Input,KeyboardInput
 if s['ime'] and u.IsWindow(s['ime']):u.SendMessageW(s['ime'],0x283,2,s['conversion'])
 if bool(u.GetKeyState(144)&1)!=s['numlock']:
  u.SendInput.argtypes=[w.UINT,c.POINTER(Input),c.c_int]
  events=(Input*2)(Input(kind=1,keyboard=KeyboardInput(vk=144)),Input(kind=1,keyboard=KeyboardInput(vk=144,flags=2)))
  assert u.SendInput(2,events,c.sizeof(Input))==2;time.sleep(.15)
 if s['foreground'] and u.IsWindow(s['foreground']):u.SetForegroundWindow(s['foreground'])
 after=snapshot();r=dict(before=s,after=after,numlock_restored=after['numlock']==s['numlock'],ime_restored=(int(u.SendMessageW(s['ime'],0x283,1,0))==s['conversion']) if s['ime'] and u.IsWindow(s['ime']) else '원래 컨텍스트 소멸/없음')
 assert r['numlock_restored'] and r['ime_restored'] is not False,r
 return r
