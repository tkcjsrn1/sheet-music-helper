"""새 exe에 든 표기·재생 함수의 입력 계약을 직접 확인한다. 소리 청취는 별도다."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,sys
from PyInstaller.archive.readers import CArchiveReader
R=Path.cwd();sys.path.insert(0,str(R));O=Path(sys.argv[1]);info=json.loads((O/'artifacts.json').read_bytes());exe=Path(info['exe']['path'])
with exe.open('rb') as stream: assert hashlib.file_digest(stream,'sha256').hexdigest().upper()==info['exe']['sha256']
archive=CArchiveReader(str(exe)).open_embedded_archive('PYZ.pyz')
assert 'modules.piano_keyboard' in archive.toc,'새 건반 모듈 frozen 누락'
naming={'__name__':'frozen_naming','__package__':'modules'};audio={'__name__':'frozen_audio','__package__':'modules'}
exec(archive.extract('modules.note_namer'),naming);exec(archive.extract('modules.label_audio'),audio)
rows=[]
for letter,kind,text,midi in [('D','bb','레bb',60),('F','##','파##',67)]:
    note=SimpleNamespace(note_name=letter,octave=4)
    acc,named=naming['apply_double_accidentals']([note],[None],[(note,'기존')],{0:(kind,'직접')},('F',),'♯')
    assert acc==[kind] and named[0][1]==text
    label=dict(staff=0,x=100,pitch=letter+'4',accidental=acc[0],text=named[0][1],confidence='check',flags=['double_acc'])
    music=dict(key_symbol='♯',key_letters=['F'],notation='solfege')
    assert audio['pitch_to_midi'](label,music)==midi
    plan,plan_skip=audio['audio_plan'](dict(labels=[label],music=music),False);assert plan==[dict(notes=[midi],indices=[0])] and not plan_skip
    groups,skip=audio['audio_groups'](dict(labels=[label],music=music),False);assert groups==[[midi]] and not skip
    skipped_groups,skip=audio['audio_groups'](dict(labels=[label],music=music),True);assert not skipped_groups and len(skip)==1
    rows.append(dict(input=label,music=music,midi=midi,hz=440*2**((midi-69)/12),check_kept=True,skip_option_respected=True))
label=dict(staff=0,x=100,pitch='D5',accidental=None,text='레b',confidence='certain',key=dict(key_symbol='♭',key_letters=['B','E','A','D','G'],tonic='Db'))
assert audio['pitch_to_midi'](label,dict(key_symbol='',key_letters=[],notation='solfege'))==73
out=dict(build_commit=info['build_commit'],exe_sha256=info['exe']['sha256'],method='PYZ 실제 frozen 함수 추출 · 명시적 fixture 입력',not_an_optical_recognition_or_gui_sound_test=True,fixtures=rows,modulation_D5_Db_midi=73)
(O/'frozen-double-contract.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('frozen 레bb=C4(60), 파##=G4(67), check·제외 옵션 유지, 구간조표 레b=73 통과')
