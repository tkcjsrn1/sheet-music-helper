"""이전 실제015908d 베타12입력·새 소스/exe 전체 원문을 대조한다."""
import collections,ctypes,gzip,hashlib,json,os,shutil,subprocess,sys,time,zipfile
from pathlib import Path
import numpy as np
from PIL import Image
R=Path.cwd();P=Path('F:/sheet-music-helper-beta-13d73f6-record-20261018')
B=Path(sys.argv[1]);info=json.loads((B/'build-info.json').read_bytes());commit=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert info['commit']==commit and not info['dirty']
Z=B.parent/('악보헬퍼-'+B.name+'.zip');O=Path(sys.argv[2]);O.mkdir(parents=True,exist_ok=True)
meta=O/'run-meta.json';identity=dict(commit=commit,exe_sha256=info['exe']['sha256'])
if meta.exists():assert json.loads(meta.read_bytes())==identity
else:meta.write_text(json.dumps(identity),encoding='utf-8')
def sha(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest().upper()
with zipfile.ZipFile(Z) as archive:
    assert set(archive.namelist())=={'악보헬퍼.exe','build-info.json','먼저 읽어주세요.txt','LICENSE','THIRD_PARTY_NOTICES.txt'}
    clean=O/'한글 새 폴더'
    if not clean.exists():clean.mkdir();archive.extractall(clean)
exe=clean/'악보헬퍼.exe';assert sha(exe)==info['exe']['sha256']
env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',TEMP=str(O/'temp'),TMP=str(O/'temp'));Path(env['TEMP']).mkdir(exist_ok=True)
exe_env=dict(env,PATH=os.environ['SystemRoot']+'\\System32;'+os.environ['SystemRoot']);exe_env.pop('PYTHONPATH',None);assert shutil.which('python',path=exe_env['PATH']) is None
class M(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ('physical','available','pagefile','available_pagefile','virtual','available_virtual','extended')]
def memory():
    m=M();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));return m.available
samples=[]
def run(args,name,expected=0,frozen=False):
    marker=O/(name+'.exit.json');expect=dict(args=list(map(str,args)),expected=expected)
    if marker.exists():
        saved=json.loads(marker.read_bytes());assert {k:saved[k] for k in expect}==expect and saved['returncode']==expected
        return
    assert memory()>=int(2.5*1024**3),'실행 전 메모리 부족'
    with (O/(name+'.log')).open('wb') as log:
        p=subprocess.Popen(args,cwd=R,env=exe_env if frozen else env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        while p.poll() is None:
            free=memory();samples.append(dict(stage=name,available_bytes=free));(O/'memory.json').write_text(json.dumps(samples),encoding='utf-8')
            if free<1024**3:
                subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT);raise RuntimeError('메모리 부족: 본인 트리 중단')
            time.sleep(5)
    assert p.returncode==expected,(name,p.returncode)
    marker.write_text(json.dumps(dict(expect,returncode=p.returncode)),encoding='utf-8')
def pixels(p):return np.asarray(Image.open(p).convert('RGB'))
enc=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
counts=lambda labels:collections.Counter(map(enc,labels))
sys.path.insert(0,str(R));from tools.compare_beta_labels import count_changes
old_rows=json.loads((P/'output/strict-double-connection/result.json').read_bytes());old_verify=json.loads(Path('F:/sheet-music-helper-progress-test-20261020/output/release-015908d/verification.json').read_bytes());old_cases={r['case']:r for r in old_verify['cases']}
reuse={k:k for k in ('aoharu_p1','chopin_Db_p1','bach_p1')}
INTEGRATED=Path('F:/sheet-music-helper-beta-cf4dd44-20261019')
source_identity=[]
for path in [*R.glob('modules/*.py'),R/'main.py',R/'gui.py',R/'user_messages.py',*R.glob('assets/*')]:
    if path.is_file():
        a=path.read_bytes();b=(INTEGRATED/path.relative_to(R)).read_bytes()
        assert a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),(str(path),'재사용 소스와 제품 코드 다름')
        source_identity.append(dict(path=str(path.relative_to(R)),raw_equal=a==b,lf_equal=True))
(O/'source-reuse-identity.json').write_text(json.dumps(source_identity,ensure_ascii=False,indent=2),encoding='utf-8')
results=[];strict=[]
for row in old_rows:
    case=row['case'];src=Path(row['input']);assert src.is_file();before_raw=Path(old_cases[case]['exe_json']).read_bytes();before=json.loads(before_raw)
    assert sha(src).lower()==before['source']['sha256']
    source=O/(case+'-source');source.mkdir(exist_ok=True)
    if case in reuse:
        for old in (Path('F:/akbo-data/tmp/merge-beta-20261023/defaults')/reuse[case]).glob('*'):
            if old.suffix.lower() in ('.png','.json'):shutil.copyfile(old,source/old.name)
    else:run([sys.executable,'-B','gui.py','--selftest',str(src),str(source)],case+'-source')
    sj=next(source.glob('*_라벨.json'));sp=next(source.glob('*_계이름.png'));after=json.loads(sj.read_bytes())
    if sj.read_bytes()!=before_raw:
        (O/(case+'-unexpected.json')).write_text(json.dumps(dict(before=before,after=after),ensure_ascii=False,indent=2),encoding='utf-8')
        raise AssertionError((case,'015908d 실제exe JSON 전체 바이트 변화: 중단'))
    assert np.array_equal(pixels(sp),pixels(old_cases[case]['exe_png'])),(case,'기본 PNG 이전015908d 화소 변화')
    assert {k:v for k,v in before.items() if k not in ('labels','schema')}=={k:v for k,v in after.items() if k not in ('labels','schema')},(case,'문맥 변화')
    if case.startswith('aoharu'):assert before==after,(case,'골든 기본 JSON 변화')
    target=O/(case+'-exe');run([str(exe),'--selftest',str(src),str(target)],case+'-exe',frozen=True)
    ej=next(target.glob('*_라벨.json'));ep=next(target.glob('*_계이름.png'))
    assert sj.read_bytes()==ej.read_bytes(),(case,'소스/exe 전체 JSON 바이트 변화')
    assert np.array_equal(pixels(sp),pixels(ep)),(case,'소스/exe PNG 화소 변화')
    if case in ('aoharu_p1','chopin_Db_p1'):assert ej.read_text(encoding='utf-8')==(R/'tests/fixtures/selftest'/f'{case}.json').read_text(encoding='utf-8')
    relabel=O/(case+'-relabel');run([str(exe),str(src),'--relabel',str(ej),'--output-dir',str(relabel),'--no-debug'],case+'-relabel',frozen=True)
    assert np.array_equal(pixels(ep),pixels(next(relabel.glob('*_계이름.png')))),(case,'재렌더 화소 변화')
    changed,diff=count_changes(before,after)
    strict.append(dict(case=case,input_sha256=sha(src),baseline_json_sha256=hashlib.sha256(before_raw).hexdigest(),before=before,after=after,counts=changed,differences=diff))
    results.append(dict(case=case,input_sha256=sha(src),labels=len(after['labels']),staves=len(after['staves']),confidence=dict(collections.Counter(l['confidence'] for l in after['labels'])),music=after['music'],baseline_015908d_json_raw_equal=True,baseline_015908d_pixels_equal=True,source_exe_json_raw_equal=True,source_exe_pixels_equal=True,exe_relabel_pixels_equal=True,source_reused=(case in reuse),exe_json=str(ej),exe_png=str(ep),json_sha256=sha(ej)))
    (O/'verification.json').write_text(json.dumps(dict(build_commit=commit,cases=results),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with gzip.open(O/'strict-rows.json.gz','wb') as f:f.write(json.dumps(strict,ensure_ascii=False).encode('utf-8'))
    print(case,len(after['labels']),changed,'승인 행·소스/exe JSON·PNG·재렌더 같음',flush=True)
# 새 폴더 첫 CLI 실행: settings가 없어야 하고 output이 exe 옆에 생겨야 한다.
assert not (clean/'settings.json').exists()
run([str(exe),str(Path(old_rows[0]['input'])),'--no-debug'],'default-output',frozen=True)
assert len(list((clean/'output').glob('*_계이름.png')))==1 and len(list((clean/'output').glob('*_라벨.json')))==1
wrong=Path(next(r for r in results if r['case']=='chopin_Db_p1')['exe_json'])
run([str(exe),str(Path(old_rows[0]['input'])),'--relabel',str(wrong),'--output-dir',str(O/'wrong-input'),'--no-debug'],'wrong-input',expected=1,frozen=True)
assert not list((O/'wrong-input').glob('*_계이름.png'))
result=dict(build_commit=commit,cases=results,python_removed_from_path=True,settings_absent_cli_first_run=True,exe_adjacent_default_output=True,wrong_input_relabel_rejected=True,zip_files=zipfile.ZipFile(Z).namelist())
(O/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
art=dict(build_commit=commit,verification_status='in_progress')
for key,path in [('exe',B/'악보헬퍼.exe'),('zip',Z)]:art[key]=dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
(O/'artifacts.json').write_text(json.dumps(art,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('015908d 엄격12입력 변화0·소스/exe·새폴더·ZIP5·오입력거부 완료',flush=True)
