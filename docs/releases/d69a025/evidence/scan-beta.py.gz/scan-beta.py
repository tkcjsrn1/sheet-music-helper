import hashlib,json,subprocess,sys
from pathlib import Path
O=Path(sys.argv[1]);art=json.loads((O/'artifacts.json').read_bytes())
choices=list(Path('C:/ProgramData/Microsoft/Windows Defender/Platform').glob('*/MpCmdRun.exe'));assert choices,'Defender 검사기 없음'
scanner=max(choices,key=lambda p:p.stat().st_mtime)
def ps(command):
 r=subprocess.run(['powershell','-NoProfile','-Command',"[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;$ErrorActionPreference='Stop';"+command],capture_output=True)
 assert r.returncode==0,r.stderr.decode(errors='replace')
 raw=r.stdout.decode('utf-8-sig').strip();return json.loads(raw) if raw else []
versions=ps('Get-MpComputerStatus|Select-Object AMProductVersion,AMEngineVersion,AntivirusSignatureVersion,AntivirusSignatureLastUpdated,AntivirusEnabled,RealTimeProtectionEnabled|ConvertTo-Json')
assert versions['AntivirusEnabled'],'Defender가 꺼져 있음: 미검증'
rows=[]
for kind in ('exe','zip'):
 path=Path(art[kind]['path'])
 with path.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest().upper()==art[kind]['sha256']
 with (O/('defender-'+kind+'.log')).open('wb') as log:
  p=subprocess.run([str(scanner),'-Scan','-ScanType','3','-File',str(path)],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 detections=ps('Get-MpThreatDetection|Select-Object ThreatID,InitialDetectionTime,LastThreatStatusChangeTime,ActionSuccess,Resources|ConvertTo-Json -Depth 6')
 if isinstance(detections,dict):detections=[detections]
 relevant=[d for d in detections if any(str(Path(art[k]['path'])).lower() in str(r).lower() for r in (d.get('Resources') or []) for k in ('exe','zip'))]
 threats=[]
 if relevant:
  all_threats=ps('Get-MpThreat|Select-Object ThreatID,ThreatName,IsActive|ConvertTo-Json')
  if isinstance(all_threats,dict):all_threats=[all_threats]
  threats=[t for t in all_threats if t['ThreatID'] in {d['ThreatID'] for d in relevant}]
 rows.append(dict(kind=kind,path=str(path),exit=p.returncode,sha256=art[kind]['sha256'],detections=relevant,threats=threats))
 (O/'defender.json').write_text(json.dumps(dict(scanner=str(scanner),versions=versions,scans=rows),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 assert p.returncode==0 and not relevant,('Defender 실패/탐지, 우회 없이 중단',kind,rows[-1])
 print('Defender',kind,'종료0·해당 경로 탐지0',flush=True)

subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('frozen-contract.py')),str(O)],check=True)
