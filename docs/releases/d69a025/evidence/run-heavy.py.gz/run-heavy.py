import json,os,subprocess,sys,time
from pathlib import Path
from datetime import datetime
from monitor import measure,system,G
B=Path(__file__).parent;R=Path('F:/akbo-data/tmp/beta-features-20261023');J=Path('F:/sheet-music-helper-beta-cf4dd44-20261019')
name=sys.argv[1];args=sys.argv[2:]
env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',PYTHONPATH=str(B/'runtime'),TEMP=str(B/'temp'),TMP=str(B/'temp'),PYINSTALLER_CONFIG_DIR=str(B/'pyinstaller-cache'),LOW_MEMORY_PROOF=str(B/(name+'-workers.jsonl')),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
deadline=time.monotonic()+3600
while Path('F:/akbo-data/HEAVY.lock').exists() or system()['available']<2.75*G or system()['commit_headroom']<3*G:
 if time.monotonic()>deadline:raise RuntimeError('잠금/메모리 1시간 대기, 새 실행0')
 time.sleep(2)
subprocess.run(['git','pull','--ff-only'],cwd=J,check=True,capture_output=True)
with (J/'WORKLOG.md').open('a',encoding='utf-8') as f:f.write(f'\n\n## [codex] 내부베타 d69a025 무거운 실행 시작 — {datetime.now().astimezone().isoformat()}\n\n작업 {name}, 기준 d69a025 고정(건반·줄옵션·#425). 골든1/OpenCV1/가용2.5GiB 시작·1GiB 미만 중단, F: 본인 Job·잠금만 사용한다.\n')
input_state=None
if name=='frozen-gui':
 import importlib.util
 spec=importlib.util.spec_from_file_location('input_restore',B/'input-restore.py');state_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(state_module)
 input_state=state_module.snapshot();(B/'input-before.json').write_text(json.dumps(input_state),encoding='utf-8')
try:
 result=measure(name,[sys.executable,'-B',*args],R,B/name,env,900 if name=='frozen-gui' else 5400)
 assert result['exit_code']==0 and not result['aborted'],result
finally:
 if input_state is not None:
  (B/'input-cleanup.json').write_text(json.dumps(state_module.restore(input_state),ensure_ascii=False,indent=2),encoding='utf-8')
 with (J/'WORKLOG.md').open('a',encoding='utf-8') as f:f.write(f'\n- 무거운 실행 끝 {datetime.now().astimezone().isoformat()}: {name}, 원자료 F:/akbo-data/tmp/merge-beta-20261023/{name}. 성공 여부는 단계 원문으로 구분, 본인 잠금·Job 정리.\n')
