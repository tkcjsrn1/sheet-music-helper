"""4fc3343 실제 exe 결과와 새 main을 비교한다. 승인 전후행 밖 차이는 즉시 중단한다."""
import collections,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));W=R/'output/strict-beta-383-20261016';W.mkdir(exist_ok=False)
from tools.compare_beta_labels import count_changes
meta=json.loads((R/'docs/releases/4fc3343/artifacts.json').read_text(encoding='utf-8'))
oldexe=Path(meta['exe']['path']);assert hashlib.sha256(oldexe.read_bytes()).hexdigest().upper()==meta['exe']['sha256']
oldverify=json.loads((R/'docs/releases/4fc3343/verification.json').read_text(encoding='utf-8'))
known={r['case']:r for r in oldverify['cases']}
source=Path('C:/Users/정혁/Desktop/악보헬퍼/debug/sim_lp')
cases=[('aoharu_p1','sample_images/KakaoTalk_20260731_162400402.png','aoharu1'),('aoharu_p2','sample_images/KakaoTalk_20260731_162400402_01.png','aoharu2'),('aoharu_p3','sample_images/KakaoTalk_20260731_162400402_02.png','aoharu3'),('chopin_Db_p1','tests/fixtures/selftest/chopin_Db_p1.png','db1'),('bach_p1','output/night-inputs/bach_p1.png','bach'),('clef_change_clara1','test_scores/verovio/clara_polonaise_1_bravura_p1.png','clara_polonaise_1_bravura_p1'),('alto_beethoven1','test_scores/verovio/beethoven_op18no1_bravura_p1.png','beethoven_op18no1_bravura_p1'),('schubert_restored','test_scores/verovio/schubert_lindenbaum_piano_leipzig_p1.png','schubert_lindenbaum_piano_leipzig_p1')]
for alias,stem in [('clara1_leipzig','clara_polonaise_1_leipzig_p1'),('clara2_bravura','clara_polonaise_2_bravura_p1'),('clara2_leipzig','clara_polonaise_2_leipzig_p1'),('schubert_bravura','schubert_lindenbaum_piano_bravura_p1')]:cases.append((alias,'test_scores/verovio/'+stem+'.png',stem))
KEYS={stem for _,_,stem in cases if stem.startswith(('clara_','schubert_'))}
assert len(KEYS)==6 and len(cases)==12
enc=lambda x:json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
count=lambda rows:collections.Counter(map(enc,rows))
env=dict(os.environ,PYTHONIOENCODING='utf-8')
exeenv=dict(env,PATH=os.environ['SystemRoot']+'\\System32;'+os.environ['SystemRoot'])
def run(args,out,environment):
 p=subprocess.run(args,cwd=R,env=environment,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 out.write_bytes(p.stdout);assert p.returncode==0,(args,p.returncode)
rows=[];refs=[]
for case,path,stem in cases:
 path=R/path;assert path.exists(),path
 ref={}
 for phase in ('dblacc','fbeam','keychg'):
  raw=(source/phase/(stem+'.json')).read_bytes();ref[phase]=json.loads(raw)
  refs.append(dict(case=case,phase=phase,sha256=hashlib.sha256(raw).hexdigest(),document=ref[phase]))
 a,b,c=(ref[p]['labels'] for p in ('dblacc','fbeam','keychg'))
 assert len(a)==len(b)==len(c),(case,'CLI 원자료 라벨 수 변화')
 for old,mid,new in zip(a,b,c):
  assert {k:v for k,v in old.items() if k not in ('confidence','flags')}=={k:v for k,v in mid.items() if k not in ('confidence','flags')},(case,'#377/381 원자료의 표시 외 변화')
  if old!=mid:
   assert [f for f in mid['flags'] if f not in ('text_row','beam_sloped') or f in old['flags']]==old['flags'],(case,'#377/381 원자료의 다른 신호 변화')
   assert mid['confidence']=='check',(case,'check 아닌 변화')
  assert {k:v for k,v in mid.items() if k!='text'}=={k:v for k,v in new.items() if k!='text'},(case,'#383 원자료의 표기 외 변화')
  if mid['text']!=new['text']:assert stem in KEYS,(case,'6쪽 밖 표기 변화')
 if case in known:before=json.loads((R/known[case]['exe_json']).read_text(encoding='utf-8'))
 else:
  target=W/(case+'_old_exe');run([str(oldexe),'--selftest',str(path),str(target)],W/(case+'-old-exe.log'),exeenv)
  before=json.loads(next(target.glob('*_라벨.json')).read_text(encoding='utf-8'))
 assert count(before['labels'])==count(a),(case,'4fc3343 실제 exe와 CLI 기준 원자료 라벨 불일치')
 target=W/case;run([sys.executable,'main.py',str(path),'--output-dir',str(target),'--no-debug'],W/(case+'.log'),env)
 after=json.loads(next(target.glob('*_라벨.json')).read_text(encoding='utf-8'))
 assert {k:v for k,v in before.items() if k!='labels'}=={k:v for k,v in after.items() if k!='labels'},(case,'문맥 변화')
 assert len(before['labels'])==len(after['labels']),(case,'라벨 수 변화')
 for old,new in zip(before['labels'],after['labels']):
  assert {k:v for k,v in old.items() if k not in ('text','confidence','flags')}=={k:v for k,v in new.items() if k not in ('text','confidence','flags')},(case,old['x'],old['y'],'허용 외 변화')
  if old['text']!=new['text']:assert stem in KEYS,(case,'6쪽 밖 표기 변화')
 assert count(after['labels'])==count(c),(case,'CLI 승인 전후행과 다른 결과')
 changes,diff=count_changes(before,after)
 rows.append(dict(case=case,input=str(path.relative_to(R)),reference_stem=stem,before=before,after=after,counts=changes,differences=diff))
 (W/'result.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
 print(case,len(before['labels']),len(after['labels']),changes,'승인 원자료 전체행 일치',flush=True)
with gzip.open(W/'cli-accepted-references.json.gz','wb') as f:f.write(json.dumps(refs,ensure_ascii=False).encode('utf-8'))
files=[*R.glob('modules/*.py'),R/'main.py',R/'gui.py',R/'user_messages.py',*R.glob('assets/*')]
identity={str(p.relative_to(R)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
(W/'source-identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2),encoding='utf-8')
print('STRICT12_COMPLETE: 라벨 수·좌표·음고·문맥 동일, 승인 #377/381 확신도·#383 6쪽 표기 외 변화0',flush=True)