"""보존한 배치 원자료의 불변·개별 거리·새 충돌을 독립 재확인한다."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
folder = Path(__file__).resolve().parent
records = json.loads(gzip.decompress((folder / 'measurements.json.gz').read_bytes()))
proof = json.loads((folder / 'verification.json').read_text(encoding='utf-8'))
with gzip.open(root / 'docs/releases/e141908/strict-rows.json.gz', 'rt', encoding='utf-8') as f:
    staves = {r['case']: {s['id']: s['spacing'] for s in r['after']['staves']} for r in json.load(f)}

for old, new in zip(records['baseline'], records['normalise-final']):
    assert old['case'] == new['case'] and old['labels'] == new['labels']
    assert old['json_sha256'] == new['json_sha256']
    assert new['input_json_bytes_unchanged'] and new['input_objects_unchanged']
    before = {p['index']: p for p in old['placed']}
    after = {p['index']: p for p in new['placed']}
    assert before.keys() == after.keys()
    assert all(p['gap'] <= before[i]['gap'] for i, p in after.items())
    for key in ('head_hits', 'box_hits', 'bar_crossings', 'bar_edge_projections', 'order_inversions'):
        assert not set(map(tuple, new['metrics'][key])) - set(map(tuple, old['metrics'][key]))
    labels = new['labels']
    for i, a in enumerate(labels):
        for j, b in enumerate(labels[:i]):
            if (a['staff'] != b['staff'] or a['y'] == b['y'] or
                    abs(a['x'] - b['x']) >= .9 * staves[new['case']][a['staff']]):
                continue
            def order(placed):
                return (placed[i]['y'] + placed[i]['h']/2 - placed[j]['y'] - placed[j]['h']/2) * (a['y']-b['y'])
            assert order(before) < 0 or order(after) >= 0
assert len(records['baseline']) == len(records['normalise-final']) == 12
assert sum(r['metrics']['labels'] for r in records['normalise-final']) == 4721
assert all(p['equal'] and p['before_sha256'] == p['after_sha256'] for p in proof['product_pipeline'])
method = json.loads((folder / 'method.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root / 'modules/renderer.py').read_text(encoding='utf-8').encode()).hexdigest() == method['candidate_renderer_lf_sha256']
print('12쪽/4721라벨 · JSON/라벨 불변 · 개별 거리 증가/새 충돌/새 상하 역전0 · 실제 JSON3쪽 동일')
